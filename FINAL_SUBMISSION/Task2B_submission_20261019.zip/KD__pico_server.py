#!/usr/bin/env python3

import math
import time
import threading

import rclpy
from rclpy.action import ActionServer, GoalResponse, CancelResponse
from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.executors import MultiThreadedExecutor
from rclpy.node import Node

from geometry_msgs.msg import PoseStamped
from std_msgs.msg import Header

from swift_msgs.msg import SwiftMsgs
from whycode_interfaces.msg import MarkerArray
from error_msg.msg import Error
from waypoint_navigation.action import NavToWaypoint


class WayPointServer(Node):

    def __init__(self):
        super().__init__('waypoint_server')

        # ==========================================================
        # State
        # ==========================================================

        self.curr_state = [0.0, 0.0, 0.0]

        # Default target. The action client will overwrite this.
        self.desired_state = [0.0, 0.0, 13.0]

        # WhyCode yaw in degrees
        self.yaw = 0.0
        self.desired_yaw = -0.5

        self.marker_received = False

        # ==========================================================
        # PID GAINS
        #
        # X -> Pitch
        # Y -> Roll
        # Z -> Throttle
        # ==========================================================

        # Known-good Task 2A PID configuration
        self.Kp = [15.0, 15.0, 140.01]
        self.Ki = [0.08, 0.08, 0.288]
        self.Kd = [18.0, 18.0, 130.2]

        # Simple P yaw controller
        self.yaw_kp = 2.5

        self.prev_error = [0.0, 0.0, 0.0]
        self.error_sum = [0.0, 0.0, 0.0]
        self.filtered_derivative = [0.0, 0.0, 0.0]
        self.measured_velocity = [0.0, 0.0, 0.0]
        self.last_marker_time = None

        self.prev_yaw_error = 0.0

        self.first_pid = True
        self.sample_time = 0.01666

        self.integral_limit = [20.0, 20.0, 10.0]

        self.min_values = [1000, 1000, 1000]
        self.max_values = [2000, 2000, 2000]

        # ==========================================================
        # Thread protection
        # ==========================================================

        self.state_lock = threading.Lock()

        # ==========================================================
        # Drone command
        # ==========================================================

        self.cmd = SwiftMsgs()

        self.cmd.rc_roll = 1500
        self.cmd.rc_pitch = 1500
        self.cmd.rc_yaw = 1500
        self.cmd.rc_throttle = 1500
        self.cmd.rc_aux1 = 0
        self.cmd.rc_aux2 = 0
        self.cmd.rc_aux3 = 0
        self.cmd.rc_aux4 = 2000

        # ==========================================================
        # Publishers
        # ==========================================================

        self.command_pub = self.create_publisher(
            SwiftMsgs,
            '/drone_command',
            10
        )

        self.pos_error_pub = self.create_publisher(
            Error,
            '/pos_error',
            10
        )

        self.heartbeat_pub = self.create_publisher(
            Header,
            '/controller_heartbeat',
            10
        )

        # ==========================================================
        # Subscriber
        # ==========================================================

        self.create_subscription(
            MarkerArray,
            '/whycode_node/markers',
            self.whycode_callback,
            1
        )

        # ==========================================================
        # Action server
        # ==========================================================

        self._action_server = ActionServer(
            self,
            NavToWaypoint,
            'waypoint_navigation',
            execute_callback=self.execute_callback,
            goal_callback=self.goal_callback,
            cancel_callback=self.cancel_callback,
            callback_group=ReentrantCallbackGroup()
        )

        # ==========================================================
        # Timers
        # ==========================================================

        self.timer = self.create_timer(
            self.sample_time,
            self.pid
        )

        self.heartbeat_timer = self.create_timer(
            1.0,
            self.publish_heartbeat
        )

        # ==========================================================
        # Arm
        # ==========================================================

        self.arm()

        self.get_logger().info(
            'Waypoint action server started'
        )

    # ==============================================================
    # HEARTBEAT
    # ==============================================================

    def publish_heartbeat(self):

        hb = Header()
        hb.stamp = self.get_clock().now().to_msg()
        hb.frame_id = 'pico_controller_active'

        self.heartbeat_pub.publish(hb)

    # ==============================================================
    # ARM / DISARM
    # ==============================================================

    def disarm(self):

        self.cmd.rc_roll = 1000
        self.cmd.rc_pitch = 1000
        self.cmd.rc_yaw = 1000
        self.cmd.rc_throttle = 1000
        self.cmd.rc_aux4 = 1000

        self.command_pub.publish(self.cmd)

    def arm(self):

        self.disarm()

        self.cmd.rc_roll = 1500
        self.cmd.rc_pitch = 1500
        self.cmd.rc_yaw = 1500
        self.cmd.rc_throttle = 1500
        self.cmd.rc_aux4 = 2000

        self.command_pub.publish(self.cmd)

    # ==============================================================
    # WHYCODE CALLBACK
    # ==============================================================

    def whycode_callback(self, msg):

        if not msg.markers:
            return

        marker = msg.markers[0]

        position = marker.position.position
        now = time.monotonic()

        with self.state_lock:

            if self.last_marker_time is not None:

                measurement_dt = now - self.last_marker_time

                if 0.015 <= measurement_dt <= 0.10:

                    alpha = 1.0 - math.exp(-measurement_dt / 0.10)

                    for i, value in enumerate((position.x, position.y, position.z)):

                        raw_velocity = (
                            value - self.curr_state[i]
                        ) / measurement_dt

                        raw_velocity = max(
                            -3.0, min(3.0, raw_velocity)
                        )

                        self.measured_velocity[i] = (
                            (1.0 - alpha) * self.measured_velocity[i]
                            + alpha * raw_velocity
                        )

                else:

                    self.measured_velocity = [0.0, 0.0, 0.0]

            self.curr_state[0] = position.x
            self.curr_state[1] = position.y
            self.curr_state[2] = position.z
            self.last_marker_time = now

            # Boilerplate specifies WhyCode yaw in degrees.
            self.yaw = math.degrees(marker.rotation.z)

            self.marker_received = True

    # ==============================================================
    # ANGLE WRAP
    # ==============================================================

    def wrap_angle(self, angle):

        while angle > 180.0:
            angle -= 360.0

        while angle < -180.0:
            angle += 360.0

        return angle

    # ==============================================================
    # PID CONTROLLER
    # ==============================================================

    def pid(self):

        with self.state_lock:

            if not self.marker_received:
                return

            current = self.curr_state.copy()
            yaw = self.yaw
            target = self.desired_state.copy()
            measured_velocity = self.measured_velocity.copy()

        # ----------------------------------------------------------
        # Error = current - desired
        # This matches the proven Task 2A controller.
        # ----------------------------------------------------------

        error = [
            current[0] - target[0],
            current[1] - target[1],
            current[2] - target[2]
        ]

        # ----------------------------------------------------------
        # Avoid derivative kick when a new goal starts
        # ----------------------------------------------------------

        if self.first_pid:

            self.prev_error = error.copy()

            self.error_sum = [0.0, 0.0, 0.0]

            self.first_pid = False

            return

        output = [0.0, 0.0, 0.0]

        # ----------------------------------------------------------
        # X/Y/Z PID
        # ----------------------------------------------------------

        for i in range(3):

            self.error_sum[i] += (
                error[i] * self.sample_time
            )

            # Anti-windup
            if self.error_sum[i] > self.integral_limit[i]:
                self.error_sum[i] = self.integral_limit[i]

            elif self.error_sum[i] < -self.integral_limit[i]:
                self.error_sum[i] = -self.integral_limit[i]

            if i < 2:

                # X/Y damping uses filtered velocity from fresh marker
                # measurements, whose cadence differs from this PID timer.
                derivative = measured_velocity[i]
                derivative_gain = self.Kd[i]

                # Brake more firmly on approach so lateral velocity does
                # not carry the drone outside the hold boundary again.
                if abs(error[i]) < 0.8:
                    derivative_gain *= 5.0

            else:

                derivative_gain = self.Kd[i]

                # Preserve the existing Z derivative behavior.
                raw_derivative = (
                    error[i] - self.prev_error[i]
                ) / self.sample_time

                self.filtered_derivative[i] = (
                    0.70 * self.filtered_derivative[i]
                    + 0.30 * raw_derivative
                )
                derivative = max(
                    -5.0, min(5.0, self.filtered_derivative[i])
                )

            output[i] = (
                self.Kp[i] * error[i]
                + self.Ki[i] * self.error_sum[i]
                + derivative_gain * derivative
            )

        # ----------------------------------------------------------
        # Yaw P controller
        # ----------------------------------------------------------

        yaw_error = self.wrap_angle(
            yaw - self.desired_yaw
        )

        yaw_output = self.yaw_kp * yaw_error

        # ----------------------------------------------------------
        # RC mapping
        #
        # X -> Pitch
        # Y -> Roll
        # Z -> Throttle
        #
        # IMPORTANT:
        # Task 2A testing established throttle uses + output.
        # ----------------------------------------------------------

        self.cmd.rc_pitch = int(
            1500 - output[0]
        )

        self.cmd.rc_roll = int(
            1500 - output[1]
        )

        self.cmd.rc_throttle = int(
            1500 + output[2]
        )

        self.cmd.rc_yaw = int(
            1500 - yaw_output
        )

        self.cmd.rc_aux4 = 2000

        # ----------------------------------------------------------
        # Clamp
        # ----------------------------------------------------------

        self.cmd.rc_pitch = max(
            self.min_values[0],
            min(self.cmd.rc_pitch, self.max_values[0])
        )

        self.cmd.rc_roll = max(
            self.min_values[1],
            min(self.cmd.rc_roll, self.max_values[1])
        )

        self.cmd.rc_throttle = max(
            self.min_values[2],
            min(self.cmd.rc_throttle, self.max_values[2])
        )

        self.cmd.rc_yaw = max(
            1000,
            min(self.cmd.rc_yaw, 2000)
        )

        # ----------------------------------------------------------
        # Save state
        # ----------------------------------------------------------

        self.prev_error = error.copy()
        self.prev_yaw_error = yaw_error

        # ----------------------------------------------------------
        # Publish command
        # ----------------------------------------------------------

        self.command_pub.publish(self.cmd)

        # ----------------------------------------------------------
        # Publish /pos_error
        # ----------------------------------------------------------

        pos_error = Error()

        pos_error.pitch_error = float(error[0])
        pos_error.roll_error = float(error[1])
        pos_error.throttle_error = float(error[2])
        pos_error.yaw_error = float(yaw_error)

        self.pos_error_pub.publish(pos_error)

    # ==============================================================
    # ACTION GOAL CALLBACK
    # ==============================================================

    def goal_callback(self, goal_request):

        self.get_logger().info(
            'Received new waypoint goal request'
        )

        return GoalResponse.ACCEPT

    # ==============================================================
    # ACTION CANCEL CALLBACK
    # ==============================================================

    def cancel_callback(self, goal_handle):

        self.get_logger().info(
            'Received goal cancellation request'
        )

        return CancelResponse.ACCEPT

    # ==============================================================
    # CHECK WHETHER POSITION IS WITHIN ±0.4 ON EVERY AXIS
    # ==============================================================

    def waypoint_reached(self):

        with self.state_lock:

            x_error = abs(
                self.curr_state[0] - self.desired_state[0]
            )

            y_error = abs(
                self.curr_state[1] - self.desired_state[1]
            )

            z_error = abs(
                self.curr_state[2] - self.desired_state[2]
            )

        return (
            x_error <= 0.4
            and y_error <= 0.4
            and z_error <= 0.4
        )

    # ==============================================================
    # ACTION EXECUTION
    # ==============================================================

    def execute_callback(self, goal_handle):

        self.get_logger().info(
            'Executing waypoint goal...'
        )

        waypoint = goal_handle.request.waypoint

        new_target = [
            waypoint.position.x,
            waypoint.position.y,
            waypoint.position.z
        ]

        # ----------------------------------------------------------
        # Set new target
        # ----------------------------------------------------------

        with self.state_lock:

            self.desired_state = new_target

            # Reset PID state for the new waypoint
            self.prev_error = [
                self.curr_state[0] - new_target[0],
                self.curr_state[1] - new_target[1],
                self.curr_state[2] - new_target[2]
            ]

            self.error_sum = [0.0, 0.0, 0.0]
            self.filtered_derivative = [0.0, 0.0, 0.0]

            self.first_pid = True

        self.get_logger().info(
            f'New Waypoint: '
            f'X={new_target[0]:.2f}, '
            f'Y={new_target[1]:.2f}, '
            f'Z={new_target[2]:.2f}'
        )

        # ----------------------------------------------------------
        # Action feedback
        # ----------------------------------------------------------

        feedback_msg = NavToWaypoint.Feedback()

        # ----------------------------------------------------------
        # Timing
        # ----------------------------------------------------------

        goal_start_time = time.monotonic()

        stable_start_time = None
        stable_duration = 0.0

        required_stable_time = 3.0

        # ----------------------------------------------------------
        # Execute until the waypoint is stable for 3 seconds
        # ----------------------------------------------------------

        while rclpy.ok():

            # ------------------------------------------------------
            # Handle cancellation
            # ------------------------------------------------------

            if goal_handle.is_cancel_requested:

                goal_handle.canceled()

                result = NavToWaypoint.Result()

                result.hov_time = int(
                    round(time.monotonic() - goal_start_time)
                )

                self.get_logger().info(
                    'Waypoint goal cancelled'
                )

                return result

            # ------------------------------------------------------
            # Current position
            # ------------------------------------------------------

            with self.state_lock:

                current = self.curr_state.copy()

            # ------------------------------------------------------
            # Feedback
            # ------------------------------------------------------

            feedback_msg.current_waypoint = PoseStamped()

            feedback_msg.current_waypoint.header.stamp = (
                self.get_clock().now().to_msg()
            )

            feedback_msg.current_waypoint.header.frame_id = (
                'whycode'
            )

            feedback_msg.current_waypoint.pose.position.x = (
                current[0]
            )

            feedback_msg.current_waypoint.pose.position.y = (
                current[1]
            )

            feedback_msg.current_waypoint.pose.position.z = (
                current[2]
            )

            feedback_msg.current_waypoint.pose.orientation.w = 1.0

            goal_handle.publish_feedback(
                feedback_msg
            )

            # ------------------------------------------------------
            # Tolerance check
            # ------------------------------------------------------

            inside_tolerance = self.waypoint_reached()

            if inside_tolerance:

                if stable_start_time is None:

                    stable_start_time = time.monotonic()

                    self.get_logger().info(
                        'Waypoint tolerance reached; '
                        'starting 3-second stabilization'
                    )

                stable_duration = (
                    time.monotonic() - stable_start_time
                )

            else:

                if stable_start_time is not None:

                    self.get_logger().info(
                        'Left waypoint tolerance; '
                        'stabilization timer reset'
                    )

                stable_start_time = None
                stable_duration = 0.0

            # ------------------------------------------------------
            # Success after 3 continuous seconds
            # ------------------------------------------------------

            if (
                stable_start_time is not None
                and stable_duration >= required_stable_time
            ):

                goal_handle.succeed()

                result = NavToWaypoint.Result()

                total_time = (
                    time.monotonic() - goal_start_time
                )

                result.hov_time = int(
                    round(total_time)
                )

                self.get_logger().info(
                    f'Waypoint stabilized successfully '
                    f'in {total_time:.2f} s'
                )

                return result

            # ------------------------------------------------------
            # Prevent busy spinning
            # ------------------------------------------------------

            time.sleep(0.02)

        # ----------------------------------------------------------
        # ROS shutdown
        # ----------------------------------------------------------

        result = NavToWaypoint.Result()

        result.hov_time = 0

        return result


# ==================================================================
# MAIN
# ==================================================================

def main(args=None):

    rclpy.init(args=args)

    waypoint_server = WayPointServer()

    executor = MultiThreadedExecutor(
        num_threads=4
    )

    executor.add_node(
        waypoint_server
    )

    try:

        executor.spin()

    except KeyboardInterrupt:

        waypoint_server.get_logger().info(
            'KeyboardInterrupt, shutting down.'
        )

    finally:

        waypoint_server.disarm()

        waypoint_server.destroy_node()

        rclpy.shutdown()


if __name__ == '__main__':
    main()
