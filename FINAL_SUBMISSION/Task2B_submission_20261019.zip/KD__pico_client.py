#!/usr/bin/env python3

import rclpy
from rclpy.action import ActionClient
from rclpy.node import Node

from waypoint_navigation.action import NavToWaypoint
from waypoint_navigation.srv import GetWaypoints


class WayPointClient(Node):

    def __init__(self):
        super().__init__('waypoint_client')

        self.goals = []
        self.marker_ids = []
        self.goal_index = 0

        # ----------------------------------------------------------
        # Action client
        # ----------------------------------------------------------

        self.action_client = ActionClient(
            self,
            NavToWaypoint,
            'waypoint_navigation'
        )

        # ----------------------------------------------------------
        # Service client
        # ----------------------------------------------------------

        self.cli = self.create_client(
            GetWaypoints,
            'waypoints'
        )

        while not self.cli.wait_for_service(timeout_sec=1.0):
            self.get_logger().info(
                'Waypoint service not available, waiting...'
            )

        self.get_logger().info(
            'Waypoint service is available'
        )

    # ==============================================================
    # SERVICE CLIENT
    # ==============================================================

    def send_request(self):

        request = GetWaypoints.Request()

        request.get_waypoints = True

        return self.cli.call_async(request)

    def receive_goals(self):

        self.get_logger().info(
            'Requesting waypoints from service...'
        )

        future = self.send_request()

        rclpy.spin_until_future_complete(
            self,
            future
        )

        if not future.done():
            self.get_logger().error(
                'Waypoint service request did not complete'
            )
            return False

        response = future.result()

        if response is None:
            self.get_logger().error(
                'Waypoint service returned no response'
            )
            return False

        # ----------------------------------------------------------
        # Preserve the exact order returned by the service
        # ----------------------------------------------------------

        self.goals = []

        for pose in response.waypoints.poses:

            waypoint = [
                pose.position.x,
                pose.position.y,
                pose.position.z
            ]

            self.goals.append(waypoint)

        self.marker_ids = list(response.marker_ids)

        self.get_logger().info(
            f'Received {len(self.goals)} waypoints'
        )

        for i, waypoint in enumerate(self.goals):

            label = (
                self.marker_ids[i]
                if i < len(self.marker_ids)
                else f'wp{i + 1}'
            )

            self.get_logger().info(
                f'{label}: '
                f'X={waypoint[0]:.2f}, '
                f'Y={waypoint[1]:.2f}, '
                f'Z={waypoint[2]:.2f}'
            )

        if len(self.goals) == 0:

            self.get_logger().error(
                'No waypoints received'
            )

            return False

        # ----------------------------------------------------------
        # Start with the FIRST waypoint returned by service
        # ----------------------------------------------------------

        self.goal_index = 0

        self.send_goal(
            self.goals[self.goal_index]
        )

        return True

    # ==============================================================
    # ACTION CLIENT
    # ==============================================================

    def send_goal(self, waypoint):

        goal_msg = NavToWaypoint.Goal()

        goal_msg.waypoint.position.x = waypoint[0]
        goal_msg.waypoint.position.y = waypoint[1]
        goal_msg.waypoint.position.z = waypoint[2]

        # Tell the server that the waypoint must be hovered/stabilised.
        goal_msg.hover = True

        self.get_logger().info(
            f'Sending waypoint {self.goal_index + 1}/'
            f'{len(self.goals)}: '
            f'[{waypoint[0]:.2f}, '
            f'{waypoint[1]:.2f}, '
            f'{waypoint[2]:.2f}]'
        )

        # ----------------------------------------------------------
        # Wait for action server
        # ----------------------------------------------------------

        while not self.action_client.wait_for_server(
            timeout_sec=1.0
        ):

            self.get_logger().info(
                'Action server not available, waiting...'
            )

        # ----------------------------------------------------------
        # Send goal
        # ----------------------------------------------------------

        self.send_goal_future = (
            self.action_client.send_goal_async(
                goal_msg,
                feedback_callback=self.feedback_callback
            )
        )

        self.send_goal_future.add_done_callback(
            self.goal_response_callback
        )

    # ==============================================================
    # GOAL RESPONSE
    # ==============================================================

    def goal_response_callback(self, future):

        try:

            goal_handle = future.result()

        except Exception as exc:

            self.get_logger().error(
                f'Failed to send goal: {exc}'
            )

            return

        if not goal_handle.accepted:

            self.get_logger().error(
                f'Waypoint {self.goal_index + 1} was rejected'
            )

            return

        self.get_logger().info(
            f'Waypoint {self.goal_index + 1} accepted'
        )

        self.goal_handle = goal_handle

        self.get_result_future = (
            goal_handle.get_result_async()
        )

        self.get_result_future.add_done_callback(
            self.get_result_callback
        )

    # ==============================================================
    # RESULT
    # ==============================================================

    def get_result_callback(self, future):

        try:

            result = future.result().result

        except Exception as exc:

            self.get_logger().error(
                f'Failed to receive waypoint result: {exc}'
            )

            return

        self.get_logger().info(
            f'Waypoint {self.goal_index + 1} completed. '
            f'Stabilization time: {result.hov_time} s'
        )

        # ----------------------------------------------------------
        # Move to NEXT waypoint only after successful completion
        # ----------------------------------------------------------

        self.goal_index += 1

        if self.goal_index < len(self.goals):

            self.send_goal(
                self.goals[self.goal_index]
            )

        else:

            self.get_logger().info(
                '========================================'
            )

            self.get_logger().info(
                'ALL WAYPOINTS REACHED SUCCESSFULLY'
            )

            self.get_logger().info(
                'Waypoint navigation complete'
            )

            self.get_logger().info(
                '========================================'
            )

    # ==============================================================
    # FEEDBACK
    # ==============================================================

    def feedback_callback(self, feedback_msg):

        feedback = feedback_msg.feedback

        x = feedback.current_waypoint.pose.position.x
        y = feedback.current_waypoint.pose.position.y
        z = feedback.current_waypoint.pose.position.z

        self.get_logger().info(
            f'Current position: '
            f'X={x:.2f}, Y={y:.2f}, Z={z:.2f}'
        )


# ================================================================
# MAIN
# ================================================================

def main(args=None):

    rclpy.init(args=args)

    waypoint_client = WayPointClient()

    try:

        # Get waypoint list from service before navigation.
        if not waypoint_client.receive_goals():

            waypoint_client.get_logger().error(
                'Could not receive waypoints. Exiting.'
            )

            return

        rclpy.spin(
            waypoint_client
        )

    except KeyboardInterrupt:

        waypoint_client.get_logger().info(
            'KeyboardInterrupt, shutting down.'
        )

    finally:

        waypoint_client.destroy_node()

        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
