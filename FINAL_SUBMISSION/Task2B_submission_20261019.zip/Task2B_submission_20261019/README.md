# e-Yantra Khoj-o-Drone Stage 1 Task 2B submission bundle

## Required scripts

The required Python scripts are at the ZIP root with the exact names:

- `KD__waypoint_service.py`
- `KD__pico_client.py`
- `KD__pico_server.py`

They are the functioning Python implementation. The repository's C++ alternatives are starter stubs and are not included as working versions.

## Required launch order

Follow the Task 2B procedure so the evaluation timer does not include a client waiting for a server that was started too early:

1. Launch the simulator.
2. Start rosbag recording before starting the waypoint service, client, or action server.
3. Start `waypoint_service`.
4. Start `pico_client`; it gets the service waypoints and waits for the action server.
5. Start `pico_server` immediately afterward. This releases the waiting first goal and begins the route.
6. Stop the recorder only after the client reports `ALL WAYPOINTS REACHED SUCCESSFULLY`.

The earlier 35/40 result had WP1 at 50.03 s and later legs at about 8.4 s each. The previous bag shows a 42.19 s gap from action-server startup to the first waypoint goal, matching the excess WP1 time. The corrected run below used the prescribed order.

## Rosbag

The root-level `metadata.yaml` and `task_2b_KD_submission_correct_order_20261019_0.db3` form the rosbag when this ZIP is extracted into an empty directory. The same files are also in `Task2B_submission_20261019/recording/` for convenience. The bag records `/rosout`, `/whycode_node/markers`, `/pos_error`, `/drone_command`, and `/controller_heartbeat`; it was started before the Task 2B nodes and closed cleanly.

## Corrected-order local result

The service returned the four specified waypoints in order. The client completed each action before sending the next, and all 3-second holds passed at the required ±0.4 tolerance. Action times were 8.27, 8.35, 8.45, and 8.24 seconds (33.31 seconds summed; 33.43 seconds from action-server startup to final stabilization). The client reported all waypoints reached successfully. This is a local simulation result; official 40/40 with this corrected launch order has not yet been confirmed.

## Bundle contents

- `scripts/`: copies of the three KD-prefixed Python scripts.
- `source/`: simulation launch and Fast DDS configuration.
- `interfaces/`: action and service definitions.
- `results/`: trial record.
- `recording/`: the corrected-order rosbag.

Full project branch: https://github.com/kunsangg/Khojo-O-Drone/tree/task2b-measured-controller
