# Task 2B controller trial

## Requirements kept unchanged

- Waypoints are supplied by the `waypoints` service in the required order.
- The `waypoint_navigation` action completes each goal before the client sends the next.
- Each waypoint requires 3 uninterrupted seconds within ±0.4 WhyCode units on X, Y, and Z.
- The route limit is 100 seconds; full speed marks require 40 seconds.

## Local simulation results

On 2026-10-19, the local ROS 2 / MuJoCo simulation completed all four holds with the measured-velocity controller at X/Y `Kp=9.99`. The client-reported action durations were 19, 20, 20, and 19 seconds, approximately 78 seconds total. The complete bag is `task_2b_velocity_feedback_retry_20261019`.

A controlled X/Y proportional-gain trial at `Kp=15.0` completed all four holds twice:

| Trial | WP1 | WP2 | WP3 | WP4 | Route total |
| --- | ---: | ---: | ---: | ---: | ---: |
| A | 15.50 s | 22.93 s | 16.66 s | 15.93 s | 71.02 s |
| B | 15.63 s | 23.01 s | 16.45 s | 16.01 s | 71.10 s |

Both runs were recorded to complete bags: `task_2b_kp15_20261019` and `task_2b_kp15_repeat_20261019`. The other gains, velocity filter, action behavior, waypoint order, hold time, and tolerance were unchanged.

With X/Y `Kp=15.0`, increasing X/Y `Kd` from `12.0` to `18.0` completed all holds in two repeat trials:

| Trial | WP1 | WP2 | WP3 | WP4 | Route total |
| --- | ---: | ---: | ---: | ---: | ---: |
| A | 15.87 s | 16.54 s | 16.47 s | 15.77 s | 64.65 s |
| B | 15.53 s | 16.55 s | 16.33 s | 15.77 s | 64.18 s |

The complete bags are `task_2b_kd18_20261019` and `task_2b_kd18_repeat_20261019`.

A follow-up at X/Y `Kp=20.0` completed all holds, with action durations of 13.80, 20.63, 20.47, and 20.50 seconds (75.40 seconds total). This was slower than both `Kp=15.0` trials, mainly due to slower WP3 and WP4 completion, so the source was returned to `Kp=15.0`. Its complete bag is `task_2b_kp20_20261019`.

An X/Y `Kd=22.0` trial completed all holds in 15.57, 16.77, 16.42, and 15.51 seconds (64.27 seconds total). This is effectively the same as the repeatable `Kd=18.0` results, so the final controller keeps `Kd=18.0`; the trial bag is `task_2b_kd22_20261019`.

A far-field X/Y proportional boost (1.5× while an axis error exceeded 1.0 m) completed in 67.93 seconds and caused more hold resets, so it was removed. Its bag is `task_2b_gain_schedule_20261019`. Increasing only Y `Kd` to 24.0 completed in 64.18 seconds, equal to the best `Kd=18.0` trial, so the symmetric, repeatably tested `Kd=18.0` setting was restored. Its bag is `task_2b_ykd24_20261019`.

Increasing only X `Kp` to 20.0 completed in 67.85 seconds, slower than the repeatable symmetric `Kp=15.0` setting, so the controller was restored to `Kp=15.0` on both axes. Its bag is `task_2b_xkp20_20261019`.

The results above predate the near-target damping trials below. The reported 34/40 prior submission result is user-provided feedback and is not a score for this controller revision.

## Near-target damping trials

With the measured X/Y velocity feedback and base X/Y `Kp=15.0`, `Kd=18.0`, the controller now increases derivative damping only when an axis is within 0.8 m of its target. A first run with multipliers X `2.5×`, Y `4.0×` completed all four holds in 41.05 s (8.00, 16.64, 8.08, 8.34 s). It missed the cutoff. A second parameter set, X `3.5×`, Y `5.0×`, completed the route in 38.62 s (8.04, 14.11, 8.15, 8.32 s); the recorder failed during shutdown and did not produce valid bag metadata, so this run is not used as the submission recording.

The same X `3.5×`, Y `5.0×` settings were repeated with all required topics recorded successfully. The action server reported 8.00, 15.35, 8.15, and 8.27 s (39.77 s total). The client retrieved all four waypoints from `waypoints`, sent the goals in order, and reported all waypoints reached successfully. WP2 needed five stabilization resets; the other three waypoints each completed after their first stabilization interval. The complete bag is `task_2b_neardamp35x5y_repeat_20261019` and contains `/rosout`, `/whycode_node/markers`, `/pos_error`, `/drone_command`, and `/controller_heartbeat`.

`colcon build --packages-select swift_pico --symlink-install` completed successfully after the X `3.5×`, Y `5.0×` change, as did `python3 -m py_compile src/swift_pico/src/pico_server.py`.

## Final measured candidate

Analyzing the `task_2b_neardamp35x5y_final_20261019` bag showed that WP2 stabilization resets occurred when X crossed the ±0.4 m boundary; Y and Z remained inside tolerance. I raised only the near-target X derivative multiplier from `3.5×` to `5.0×`, leaving Y at `5.0×` and retaining the same base gains, filter, interfaces, hold, tolerance, and waypoint sequence.

The complete run in `task_2b_xnear5_ynear5_20261019` finished all four holds. Exact action-server times were 7.96, 8.46, 8.35, and 8.28 s (33.05 s summed; 33.09 s from first goal acceptance to final stabilization). From the client's service-available log to completion was 33.10 s. WP3 had one stabilization reset; WP1, WP2, and WP4 each held continuously on their first interval. The client obtained all four ordered waypoints from `waypoints`, completed each `waypoint_navigation` action before sending the next, and reported all waypoints reached. This bag was recorded after the action server was started, so it is retained as a controller-tuning record only.

The first submission recording, `task_2b_KD_submission_20261019`, started rosbag before the service and action server but incorrectly started the server before the client. There was a 42.19 s gap from action-server startup to the first waypoint goal. The user's subsequent official feedback (WP1 50.03 s; WP2 58.45 s; WP3 66.85 s; WP4 75.11 s) matches that delay plus the approximately 33 s route, so it does not show slow waypoint control.

I reran with the task's prescribed order: start recording, start the service, start the client, then start the action server immediately. The first goal arrived 0.08 s after the server became ready. The run completed all holds in 8.27, 8.35, 8.45, and 8.24 s (33.31 s summed; 33.43 s from action-server startup to final stabilization). WP1 and WP3 each had one stabilization reset; WP2 and WP4 held continuously on their first interval. The client reported all waypoints reached. The new bag is `task_2b_KD_submission_correct_order_20261019`; it was closed cleanly after recording `/rosout`, `/whycode_node/markers`, `/pos_error`, `/drone_command`, and `/controller_heartbeat`.

This final candidate is locally under the 40-second threshold with useful margin. No official evaluation has yet been run with the corrected launch order, so an official 40/40 is not confirmed. `colcon build --symlink-install` and Python syntax compilation completed successfully with the final source.
