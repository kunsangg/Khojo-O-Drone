#!/usr/bin/env python3

import rclpy
from rclpy.node import Node

from geometry_msgs.msg import Pose
from waypoint_navigation.srv import GetWaypoints


class WayPoints(Node):

    def __init__(self):
        super().__init__('waypoints_service')

        # Required waypoint order: wp1 -> wp2 -> wp3 -> wp4
        self.waypoints = [
            (-2.41, -2.41, 13.00),  # wp1
            ( 2.41,  1.20, 13.00),  # wp2
            ( 1.20, -2.41, 13.00),  # wp3
            (-1.20,  1.20, 13.00),  # wp4
        ]

        self.marker_ids = [
            'wp1',
            'wp2',
            'wp3',
            'wp4'
        ]

        self.service = self.create_service(
            GetWaypoints,
            'waypoints',
            self.waypoint_callback
        )

        self.get_logger().info(
            'Waypoint service ready: wp1 -> wp2 -> wp3 -> wp4'
        )

    def waypoint_callback(self, request, response):

        if request.get_waypoints:

            response.waypoints.poses = [
                Pose() for _ in self.waypoints
            ]

            for i, waypoint in enumerate(self.waypoints):
                response.waypoints.poses[i].position.x = waypoint[0]
                response.waypoints.poses[i].position.y = waypoint[1]
                response.waypoints.poses[i].position.z = waypoint[2]

                # Neutral orientation
                response.waypoints.poses[i].orientation.w = 1.0

            response.marker_ids = list(self.marker_ids)

            self.get_logger().info(
                'Waypoint request received'
            )

            return response

        self.get_logger().info(
            'Waypoint request rejected'
        )

        return response


def main(args=None):

    rclpy.init(args=args)

    waypoints = WayPoints()

    try:
        rclpy.spin(waypoints)

    except KeyboardInterrupt:
        waypoints.get_logger().info(
            'KeyboardInterrupt, shutting down.'
        )

    finally:
        waypoints.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
